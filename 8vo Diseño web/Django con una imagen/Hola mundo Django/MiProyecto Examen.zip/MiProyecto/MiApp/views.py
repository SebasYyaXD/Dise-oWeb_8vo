from django.shortcuts import render

def miVista(request):
    return render(request,'MiApp/miHTML.html')
